from __future__ import unicode_literals

from django.apps import AppConfig


class SupriseMeAppConfig(AppConfig):
    name = 'suprise_me_app'
