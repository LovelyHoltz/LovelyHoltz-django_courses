from __future__ import unicode_literals

from django.db import models

class Dojo(models.Model):
    dojo = models.CharField(max_length = 45)

    def __str__(self):
        return "{}".format(self.dojo)

class Ninja(models.Model):
    firstname = models.CharField(max_length = 255)
    lastname = models.CharField(max_length = 255)

    def __str__(self):
        return "{} {}".format(self.firstname, self.lastname)
