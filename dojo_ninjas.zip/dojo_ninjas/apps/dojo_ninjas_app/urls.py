from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$',views.index),
    url(r'^dojoinfo$',views.dojoinfo),
    url(r'^processdojoinfo$',views.processdojoinfo),
    #url(r'^ninjainfo$',views.ninjainfo),
    #url(r'^processninjainfo$',views.processninjainfo),
]
