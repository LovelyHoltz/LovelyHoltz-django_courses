from django.shortcuts import render, redirect

from . models import Dojo, Ninja

def index(request):
    return render(request,'dojo_ninjas_app/index.html')

def dojoinfo(request):
    context = {
        'all_dojos': Dojo.objects.all(),
        'all_ninjas': Ninja.objects.all()
    }
    return render(request,'dojo_ninjas_app/dojo.html', context)

def processdojoinfo(request):
    print request.POST
    new_location = Dojo.objects.create(
        dojo = request.POST['dojo']
    )
    Ninja.objects.create(
        firstname = request.POST['firstname'],
        lastname = request.POST['lastname'],
    )
    return redirect('/dojoinfo')

#def ninjainfo(request):
    #context = {
        #'all_ninjas': Ninja.objects.all()
    #}
    #return render(request, 'dojo_ninjas_app/dojo.html', context)

#def processninjainfo(request):
    #Ninja.objects.create(
        #firstname = request.POST['firstname'],
        #lastname = request.POST['lastname'],
    #)
    #print request.POST
    #return redirect('/dojoinfo')
