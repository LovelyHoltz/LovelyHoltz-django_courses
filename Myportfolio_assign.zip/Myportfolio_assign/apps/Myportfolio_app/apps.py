from __future__ import unicode_literals

from django.apps import AppConfig


class MyportfolioAppConfig(AppConfig):
    name = 'Myportfolio_app'
