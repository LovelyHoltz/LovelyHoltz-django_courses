from __future__ import unicode_literals

from django.apps import AppConfig


class SemirestAppConfig(AppConfig):
    name = 'semirest_app'
