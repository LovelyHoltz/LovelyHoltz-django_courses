from __future__ import unicode_literals

from django.apps import AppConfig


class BeltreviewAppConfig(AppConfig):
    name = 'beltreview_app'
