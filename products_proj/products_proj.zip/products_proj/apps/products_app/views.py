from django.shortcuts import render
from .models import models

def index(request):

    return render(request,'products_app/index.html')
