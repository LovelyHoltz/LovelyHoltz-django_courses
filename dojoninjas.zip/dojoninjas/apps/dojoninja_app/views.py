from django.shortcuts import render, redirect
from . models import Ninja

def index(request):
    return render(request,'dojoninja_app/index.html')

def newninja(request):
    context = {
        'ninjas': Ninja.objects.all()
    }
    return render(request,'dojoninja_app/newninja.html', context)

def create(request):
    Ninja.objects.create (
        dojo = request.POST['dojo'],
        firstname = request.POST['firstname'],
        lastname = request.POST['lastname']
    )
    return redirect('/newninja')
