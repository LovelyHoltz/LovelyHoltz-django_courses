from __future__ import unicode_literals

from django.db import models

class Ninja(models.Model):
    dojo = models.CharField(max_length = 100)
    firstname = models.CharField(max_length = 100)
    lastname = models.CharField(max_length = 100)

    def __str__(self):
        return "{} {}".format(self.dojo, self.firstname, self.lastname)
